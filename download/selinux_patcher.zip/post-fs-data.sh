MODDIR="${0%/*}"
if [ "$(resetprop ro.build.version.sdk)" -lt "29" ]; then
 setenforce 1
fi
chmod 440 /proc/net/unix
mount -o remount,hidepid=2 /proc
mount -o remount,nosuid /data
chmod 751 /
chmod 660 /sys/fs/selinux/enforce
chmod 440 /sys/fs/selinux/policy