MODDIR="${0%/*}"
while [ "$(resetprop sys.boot_completed)" != "1" ]; do sleep 1; done;
if [ "$(resetprop ro.build.version.sdk)" -gt "28" ]; then
 setenforce 1
fi

# for disabled Selinux

if ! mount -t selinuxfs | grep -q " /sys/fs/selinux "; then
    mount -t tmpfs selinuxfs /sys/fs/selinux
    echo "1" >/sys/fs/selinux
    touch /sys/fs/selinux/policy
    chmod 440 /sys/fs/selinux/policy
fi


#nuke selinux stuff

MAGISKTMP="$(magisk --path)"
test -z "$MAGISKTMP" && MAGISKTMP=/sbin
mkdir -p "$MAGISKTMP/selinux/patch"
mkdir -p "$MAGISKTMP/selinux/fs"
mount -t tmpfs "$MAGISKTMP/.magisk/block/data" "$MAGISKTMP/selinux/patch"
mount -t selinuxfs selinuxfs "$MAGISKTMP/selinux/fs"
echo -n "0" >"$MAGISKTMP/selinux/patch/enforce"
mount -o ro,remount "$MAGISKTMP/selinux/patch"
mount --bind "$MAGISKTMP/selinux/patch/enforce" "/sys/fs/selinux/enforce"

# always enforce
{
while true; do
   echo -n "1" > "$MAGISKTMP/selinux/fs/enforce"
   sleep 1
done
 } &