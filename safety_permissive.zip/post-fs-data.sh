setenforce 1
chmod 440 /proc/net/unix
mount -o remount,hidepid=2 /proc
mount -o remount,nosuid /data