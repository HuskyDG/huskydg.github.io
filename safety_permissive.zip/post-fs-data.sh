setenforce 1
chmod 440 /proc/net/unix
mount -o remount,hidepid=2 /proc
mount -o remount,nosuid /data
chmod 751 /
chmod 660 /sys/fs/selinux/enforce
chmod 440 /sys/fs/selinux/policy