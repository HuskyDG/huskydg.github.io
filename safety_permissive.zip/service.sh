MODDIR="${0%/*}"
while [ "$(resetprop sys.boot_completed)" != "1" ]; do sleep 1; done; resetprop ro.crypto.state encrypted
if [ "$(resetprop ro.build.version.sdk)" -gt "28" ]; then
 setenforce 1
fi

# for disabled Selinux

if ! mount -t selinuxfs | grep -q " /sys/fs/selinux "; then
    mount -t tmpfs selinuxfs /sys/fs/selinux
    echo "1" >/sys/fs/selinux
    touch /sys/fs/selinux/policy
    chmod 440 /sys/fs/selinux/policy
done


#nuke selinux stuff

MAGISKTMP="$(magisk --path)"
test -z "$MAGISKTMP" && MAGISKTMP=/sbin
mkdir -p "$MAGISKTMP/selinux"
mount -t tmpfs "$MAGISKTMP/.magisk/block/data" "$MAGISKTMP/selinux"
echo -n "0" >"$MAGISKTMP/selinux/enforce"
mount -o ro,remount "$MAGISKTMP/selinux"
mount --bind "$MAGISKTMP/selinux/enforce" "/sys/fs/selinux/enforce"