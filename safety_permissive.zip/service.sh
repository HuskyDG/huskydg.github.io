MODDIR="${0%/*}"
while [ "$(resetprop sys.boot_completed)" != "1" ]; do sleep 1; done; resetprop ro.crypto.state encrypted
if [ "$(resetprop ro.build.version.sdk)" -gt "28" ]; then
 setenforce 1
fi