while [ "$(resetprop sys.boot_completed)" != "1" ]; do sleep 1; done; resetprop ro.crypto.state encrypted
setenforce 1