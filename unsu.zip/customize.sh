#!/sbin/sh
# unSU Script: Recovery Flashable Zip
# osm0sis @ xda-developers

rm -rf /data/adb/modules_update/unsu
SKIPUNZIP=1



unzip -o "$ZIPFILE" "script.sh" -d "$TMPDIR" &>/dev/null
unshare -m sh "$TMPDIR/script.sh" $@
rm -rf "$TMPDIR/script.sh"