#!/sbin/sh
# unSU Script: Recovery Flashable Zip
# osm0sis @ xda-developers

rm -rf /data/adb/modules_update/unsu
SKIPUNZIP=1



unzip -o "$ZIPFILE" "script.sh" "revert.sh" -d "$TMPDIR" &>/dev/null
export TMPDIR
unshare -m sh "$TMPDIR/script.sh" $@
rm -rf "$TMPDIR/script.sh"